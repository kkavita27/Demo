package com.test.ToolsQADemo;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class IFrameDemo {

	public static WebDriver driver;
	public static String chDriverPath = "D:\\Kavita\\Drivers\\chromedriver\\chromedriver.exe";
	public static JavascriptExecutor jse;
	public static String sysPropCh = "webdriver.chrome.driver";
	public static final String url = "http://toolsqa.com/";
	public static WebDriverWait wait;
	public static Actions action;

	@Test
	@Parameters({})
	public static void BasicProces() {
		System.setProperty(sysPropCh, chDriverPath);
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().pageLoadTimeout(90, TimeUnit.SECONDS);
		action = new Actions(driver);
		wait = new WebDriverWait(driver, 20);
		WebElement demo_site = driver
				.findElement(By
						.xpath("(//span[@class='menu-text'][contains(text(),'DEMO SITES')])[1]"));
		wait.until(ExpectedConditions.visibilityOf((WebElement) demo_site));
		action.moveToElement(demo_site).build().perform();

	}

	@Test
	@Parameters({"firstName", "frameInput"})
	public static void workingWithIframe(String firstNameI, String frameInputI) throws InterruptedException {
		WebElement frame1 = driver
				.findElement(By
						.xpath("(//li/a[@href='http://toolsqa.com/iframe-practice-page/'])[1]"));
		wait.until(ExpectedConditions.visibilityOf(frame1));
		action.moveToElement(frame1).click(frame1).build().perform();
		driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
		driver.switchTo().defaultContent();
		driver.switchTo().frame(frameInputI); //iframe1
		System.out.println("switched to frame 1");
		jse = (JavascriptExecutor) driver;
		jse.executeScript("scroll(0, 250);");
		WebElement firstName = driver.findElement(By
				.xpath("//div/input[@name='firstname']"));
		firstName.sendKeys(firstNameI);
	}

//	public static void main(String[] args) throws InterruptedException {
//		BasicProces();
//		workingWithIframe();
//	}
}
